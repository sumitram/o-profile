---
layout: sent
title: "Thank you!"
published: true
# Do not change this permalink! If you do this, you will have to change the "_data/data.yml" file in the
# "website => content => contact => send => permalink"
# [ The two properties have to be identical.]
permalink: /contact/sent/successful/
---

Your message was sent! I will contact you as soon as possible.

---
layout: null
---

/* Cursor (pipe) flashing in the page Hello */
setInterval(function() {
  $(".layout_hello__cursor").toggle()
},600);

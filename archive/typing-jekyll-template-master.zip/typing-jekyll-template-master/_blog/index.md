---
layout: postlist
title: Blog
msg_qtd: ['There are','posts in total.']
script: [postlist.js]
permalink: /blog/
pagination: 
  enabled: true
---

What follows is a list of weblog posts from as early as {{ site.debutyear }}. I hope you enjoy

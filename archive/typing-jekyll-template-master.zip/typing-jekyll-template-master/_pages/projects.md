---
layout: page
title: Projects
sitemap:
  priority: 0.7
  changefreq: 'monthly'
  lastmod: 2017-05-04T12:49:30-05:00
in_menu: true
icon: fa-briefcase
published: true
permalink: /projects/
---

If you wanted to know about my favorite chores, this is the correct page. You find my designs of my own, or participation.

## Major collaborations

[Typing Theme](https://github.com/williamcanin/typing-jekyll-template) : Creating themes for Jekyll   


|[Typing Jekyll Template](https://github.com/williamcanin/typing-jekyll-template){:target="_blank"}|
--------------------------|----------------------------
| **Status**: <label style="color:green;">Active</label> |
| **Description**: Typing, is a template for Jekyll built especially for those who want to have a blog and pages quickly and lightly. |
